<?php

declare(strict_types=1);

namespace Psl\Option\Exception;

use Psl\Exception;

interface ExceptionInterface extends Exception\ExceptionInterface
{
}
