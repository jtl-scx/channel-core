<?php

declare(strict_types=1);

namespace Psl\Network\Exception;

final class TimeoutException extends RuntimeException
{
}
