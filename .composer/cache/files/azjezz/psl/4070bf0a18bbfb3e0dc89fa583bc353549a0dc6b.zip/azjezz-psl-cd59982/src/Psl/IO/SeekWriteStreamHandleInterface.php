<?php

declare(strict_types=1);

namespace Psl\IO;

use Psl\IO;

interface SeekWriteStreamHandleInterface extends IO\SeekWriteHandleInterface, SeekStreamHandleInterface, WriteStreamHandleInterface
{
}
