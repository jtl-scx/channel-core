<?php

declare(strict_types=1);

namespace Psl\Encoding\Exception;

use Psl\Exception;

interface ExceptionInterface extends Exception\ExceptionInterface
{
}
