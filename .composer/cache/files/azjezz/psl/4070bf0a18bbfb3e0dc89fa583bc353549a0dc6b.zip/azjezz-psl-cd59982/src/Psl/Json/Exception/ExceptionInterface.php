<?php

declare(strict_types=1);

namespace Psl\Json\Exception;

use Psl\Exception\ExceptionInterface as PslExceptionInterface;

interface ExceptionInterface extends PslExceptionInterface
{
}
