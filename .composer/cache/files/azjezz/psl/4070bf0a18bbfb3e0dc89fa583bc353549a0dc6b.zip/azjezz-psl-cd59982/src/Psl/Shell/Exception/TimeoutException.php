<?php

declare(strict_types=1);

namespace Psl\Shell\Exception;

final class TimeoutException extends RuntimeException
{
}
