<?php

declare(strict_types=1);

namespace Psl\Network\Exception;

use Psl;

interface ExceptionInterface extends Psl\Exception\ExceptionInterface
{
}
