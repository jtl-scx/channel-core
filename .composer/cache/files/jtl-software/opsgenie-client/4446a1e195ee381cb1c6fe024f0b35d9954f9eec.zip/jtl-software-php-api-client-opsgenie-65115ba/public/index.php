<?php
/**
 * This File is part of JTL-Software
 *
 * User: rherrgesell
 * Date: 7/9/18
 */

var_dump($_SERVER);
