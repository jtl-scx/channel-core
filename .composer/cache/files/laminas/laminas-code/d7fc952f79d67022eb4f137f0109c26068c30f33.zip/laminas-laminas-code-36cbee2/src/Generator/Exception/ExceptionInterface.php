<?php

namespace Laminas\Code\Generator\Exception;

use Laminas\Code\Exception\ExceptionInterface as Exception;

interface ExceptionInterface extends Exception
{
}
