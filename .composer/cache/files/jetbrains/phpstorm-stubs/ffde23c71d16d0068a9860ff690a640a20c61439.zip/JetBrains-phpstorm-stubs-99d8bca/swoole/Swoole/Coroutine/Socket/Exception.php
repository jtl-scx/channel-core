<?php

declare(strict_types=1);

namespace Swoole\Coroutine\Socket;

class Exception extends \Swoole\Exception {}
