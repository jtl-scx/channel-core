<?php

declare(strict_types=1);

namespace Swoole\Coroutine\Http\Client;

class Exception extends \Swoole\Exception {}
