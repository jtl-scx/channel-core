<?php

declare(strict_types=1);

namespace Swoole\Coroutine\Curl;

class Exception extends \Swoole\Exception {}
