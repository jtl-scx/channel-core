<?php

namespace parallel\Future;

class Error extends \parallel\Error {}
