<?php

namespace PHPSTORM_META {
    expectedArguments(\Psr\Log\LoggerInterface::log(0), 0, \Psr\Log\LogLevel::ALERT, \Psr\Log\LogLevel::CRITICAL, \Psr\Log\LogLevel::DEBUG, \Psr\Log\LogLevel::EMERGENCY, \Psr\Log\LogLevel::ERROR, \Psr\Log\LogLevel::INFO, \Psr\Log\LogLevel::NOTICE, \Psr\Log\LogLevel::WARNING);
}