<?php

namespace Relay;

/**
 * Generic Relay exception.
 */
class Exception extends \Exception {}
