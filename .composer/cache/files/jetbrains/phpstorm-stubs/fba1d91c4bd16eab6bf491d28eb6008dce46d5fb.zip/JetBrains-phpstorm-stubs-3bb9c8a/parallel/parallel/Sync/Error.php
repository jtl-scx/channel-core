<?php

namespace parallel\Sync;

class Error extends \parallel\Error {}
