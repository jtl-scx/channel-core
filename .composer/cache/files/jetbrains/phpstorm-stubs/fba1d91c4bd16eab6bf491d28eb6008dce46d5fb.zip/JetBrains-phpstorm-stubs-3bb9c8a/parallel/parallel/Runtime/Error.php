<?php

namespace parallel\Runtime;

class Error extends \parallel\Error {}
