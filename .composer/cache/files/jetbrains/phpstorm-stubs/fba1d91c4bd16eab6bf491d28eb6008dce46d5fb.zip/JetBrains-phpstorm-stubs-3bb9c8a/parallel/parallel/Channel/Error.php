<?php

namespace parallel\Channel;

class Error extends \parallel\Error {}
