<?php

namespace parallel\Runtime\Error;

use parallel\Runtime\Error;

class IllegalFunction extends Error {}
