<?php

namespace parallel\Sync\Error;

use parallel\Sync\Error;

class IllegalValue extends Error {}
