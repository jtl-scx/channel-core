<?php

namespace parallel\Events\Event;

class Error extends \parallel\Error {}
