<?php

namespace MongoDB\BSON;

/**
 * Interface Type
 * @link https://php.net/manual/en/class.mongodb-bson-type.php
 */
interface Type {}
