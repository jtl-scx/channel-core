<?php

declare(strict_types=1);

namespace Swoole\Coroutine\MySQL;

class Exception extends \Swoole\Exception {}
