<?php

declare(strict_types=1);

namespace Version\Comparison\Exception;

use Version\Exception\VersionException;

interface VersionComparisonException extends VersionException
{
}
