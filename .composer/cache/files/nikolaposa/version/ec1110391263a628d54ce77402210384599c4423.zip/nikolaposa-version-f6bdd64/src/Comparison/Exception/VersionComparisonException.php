<?php

declare(strict_types=1);

namespace Version\Comparison\Exception;

use Throwable;

interface VersionComparisonException extends Throwable
{
}
