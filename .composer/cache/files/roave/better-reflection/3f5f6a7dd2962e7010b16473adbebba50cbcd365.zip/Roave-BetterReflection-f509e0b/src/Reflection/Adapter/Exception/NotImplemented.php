<?php

declare(strict_types=1);

namespace Roave\BetterReflection\Reflection\Adapter\Exception;

use LogicException;

class NotImplemented extends LogicException
{
}
