<?php

declare(strict_types=1);

namespace Roave\BetterReflection\SourceLocator\Exception;

use RuntimeException;

class InvalidFileLocation extends RuntimeException
{
}
