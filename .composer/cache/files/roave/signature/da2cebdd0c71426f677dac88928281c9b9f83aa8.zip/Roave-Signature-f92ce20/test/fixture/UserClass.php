<?php

namespace Roave\SignatureTestFixture;

class UserClass
{
    public $name;

    protected $surname;

    private $age;
}
