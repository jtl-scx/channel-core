<?php

declare(strict_types=1);

namespace JTL\Generic;

class TestItem
{
    public $a;

    public function __construct($a)
    {
        $this->a = $a;
    }
}

class TestItem2
{
    public $a;

    public function __construct($a)
    {
        $this->a = $a;
    }
}

class TestCollection extends GenericCollection
{
    public function __construct()
    {
        parent::__construct(TestItem::class);
    }
}

class TestCollection2 extends GenericCollection
{
    public function __construct()
    {
        parent::__construct(TestItem2::class);
    }
}

class TestCollection3 extends GenericCollection
{
    public function checkType($item): bool
    {
        return true;
    }
}

class TestCollection4 extends GenericCollection
{
    public function __construct(string $type = null)
    {
        parent::__construct($type);
    }
}
