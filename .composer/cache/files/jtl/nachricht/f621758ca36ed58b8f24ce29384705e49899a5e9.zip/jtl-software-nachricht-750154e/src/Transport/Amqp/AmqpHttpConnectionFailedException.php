<?php declare(strict_types=1);
/**
 * This File is part of JTL-Software
 *
 * User: marius
 * Date: 7/27/21
 */

namespace JTL\Nachricht\Transport\Amqp;

use Exception;

class AmqpHttpConnectionFailedException extends Exception
{
}
