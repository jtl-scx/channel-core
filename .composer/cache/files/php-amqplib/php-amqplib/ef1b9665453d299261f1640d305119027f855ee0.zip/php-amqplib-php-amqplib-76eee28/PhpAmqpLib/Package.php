<?php

namespace PhpAmqpLib;

final class Package
{
    public const NAME = 'AMQPLib';
    public const VERSION = '3.6.0';
}
